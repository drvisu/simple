"""
Day 5 · EXERCISE — Evaluation-driven development
================================================
The single biggest predictor of whether a team ships good agents is whether they
run a disciplined eval + error-analysis process. Prompt-tweaking without evals
hits a ceiling you can't see.

Two kinds of checks:
  - OBJECTIVE (code-based): exact, cheap, reliable. Prefer these. (Does the
    output contain the right number? Valid JSON? The required fact?)
  - SUBJECTIVE (LLM-as-judge): for quality you can't code — scored against a
    rubric, not a vibe.

Build the eval runner. Compare to solution.py.

Run:  python day5_eval_capstone/eval_exercise.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from shared.llm import run_tool_loop, call_model, text_of
from shared.tools import ALL_SCHEMAS, dispatch


def agent(msg: str) -> str:
    ans, _ = run_tool_loop([{"role": "user", "content": msg}],
        tools=ALL_SCHEMAS, dispatch=dispatch,
        system="You are a precise assistant. Use tools rather than guessing.")
    return ans


# An eval set grows every time you find a bug: each incident becomes a test.
CASES = [
    {"id": "math",   "input": "What is 1200 * 0.15?",        "kind": "objective",
     "check": lambda out: "180" in out},
    {"id": "policy", "input": "What is our refund window?",  "kind": "objective",
     "check": lambda out: "30 days" in out.lower()},
    {"id": "tone",   "input": "Explain our SLA to a non-technical customer.",
     "kind": "judge", "rubric": "Accurate (99.9% uptime, 1-hour P1) AND simple wording."},
]


def llm_judge(question: str, answer: str, rubric: str) -> bool:
    # TODO 1: ask the model whether `answer` satisfies `rubric` for `question`.
    #         Return True if it replies PASS.
    ...


def run_evals() -> None:
    passed = 0
    for c in CASES:
        out = agent(c["input"])
        # TODO 2: for kind "objective" use c["check"](out); for "judge" use
        #         llm_judge(...). Set `ok` accordingly, print PASS/FAIL, tally.
        ok = ...
        print(f"[{'PASS' if ok else 'FAIL'}] {c['id']} ({c['kind']})")
        passed += ok
    print(f"\nScore: {passed}/{len(CASES)}")


if __name__ == "__main__":
    run_evals()
