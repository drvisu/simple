"""
shared/llm.py
=============
A thin, dependency-light wrapper around the Anthropic Messages API.

WHY THIS EXISTS
---------------
Every day of this course calls a model. Instead of repeating the same
boilerplate (client construction, message formatting, tool-loop plumbing),
we centralize it here. This is your first lesson in *harness engineering*:
the agent's "brain" (the model) is one small, swappable component. The value
you build is the scaffolding around it.

The design goal is transparency, not magic. There is no framework hiding the
control flow — you can read every line and see exactly what an agent is.

SWAPPABILITY
------------
`call_model` is the only place we talk to a provider. Point it at a different
SDK/endpoint and the rest of the course still works. In regulated settings
you would put your air-gapped / self-hosted model behind this same interface.
"""

from __future__ import annotations
import os
import json
from typing import Any, Callable

# The Anthropic SDK is the default provider for this course because it has
# first-class tool-use. `pip install anthropic`.
try:
    from anthropic import Anthropic
except ImportError:  # pragma: no cover
    Anthropic = None  # allows importing this module for reading without the dep

# A fast, cheap model is the right default for agent loops: agents make MANY
# calls, so per-call latency and cost dominate. Escalate to a bigger model only
# for the reasoning-heavy step (planning, final synthesis). This "small model
# by default, big model on escalation" pattern is the backbone of production
# agent economics.
DEFAULT_MODEL = os.environ.get("AGENT_MODEL", "claude-sonnet-5")
ESCALATION_MODEL = os.environ.get("AGENT_ESCALATION_MODEL", "claude-opus-4-8")

_client: "Anthropic | None" = None


def client() -> "Anthropic":
    """Lazily construct a single shared client (reads ANTHROPIC_API_KEY)."""
    global _client
    if Anthropic is None:
        raise RuntimeError("Run: pip install anthropic")
    if _client is None:
        _client = Anthropic()  # picks up ANTHROPIC_API_KEY from the environment
    return _client


def call_model(
    messages: list[dict],
    system: str | None = None,
    tools: list[dict] | None = None,
    model: str | None = None,
    max_tokens: int = 1024,
    temperature: float = 0.0,
) -> Any:
    """
    Single round-trip to the model. Returns the raw response object so callers
    can inspect stop_reason and content blocks (text vs tool_use).

    temperature=0.0 is the right default for *agentic* work: you want the tool
    selection to be as deterministic as possible. Turn it up only for genuinely
    creative generation steps.
    """
    kwargs: dict[str, Any] = {
        "model": model or DEFAULT_MODEL,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": messages,
    }
    if system:
        kwargs["system"] = system
    if tools:
        kwargs["tools"] = tools
    return client().messages.create(**kwargs)


def text_of(response: Any) -> str:
    """Concatenate all text blocks from a response (ignores tool_use blocks)."""
    return "".join(b.text for b in response.content if b.type == "text").strip()


# --- A tiny tool-dispatch helper used across several days -------------------

def run_tool_loop(
    messages: list[dict],
    tools: list[dict],
    dispatch: Callable[[str, dict], Any],
    system: str | None = None,
    model: str | None = None,
    max_turns: int = 8,
    on_step: Callable[[str, Any], None] | None = None,
) -> tuple[str, list[dict]]:
    """
    The canonical agent loop, factored out so later days don't re-implement it.

    Contract:
      - `tools`     : Anthropic tool schemas (name/description/input_schema).
      - `dispatch`  : your function (name, input_dict) -> result (any JSON-able).
      - `on_step`   : optional observer, called as on_step(kind, payload) for
                      tracing/observability (used on Day 5).

    Returns (final_text, full_message_history).

    This is deliberately a plain while-loop. Read it once and you understand
    what LangGraph / CrewAI / OpenAI Agents SDK are doing under the hood.
    """
    for _turn in range(max_turns):
        resp = call_model(messages, system=system, tools=tools, model=model)

        if on_step:
            on_step("model_response", resp)

        # The model is done when it stops for a reason other than needing a tool.
        if resp.stop_reason != "tool_use":
            return text_of(resp), messages

        # Otherwise: append the assistant turn, execute every requested tool,
        # and feed the results back as a user turn. Then loop.
        messages.append({"role": "assistant", "content": resp.content})

        tool_results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            if on_step:
                on_step("tool_call", {"name": block.name, "input": block.input})
            try:
                result = dispatch(block.name, block.input)
                is_error = False
            except Exception as e:  # tools must never crash the loop
                result = f"Tool error: {e}"
                is_error = True
            if on_step:
                on_step("tool_result", {"name": block.name, "result": result})
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": json.dumps(result) if not isinstance(result, str) else result,
                "is_error": is_error,
            })

        messages.append({"role": "user", "content": tool_results})

    return "Stopped: reached max_turns without a final answer.", messages
