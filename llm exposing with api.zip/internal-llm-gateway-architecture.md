# Internal LLM exposure architecture (open-source stack)

**Request path:** Internal clients → API gateway → LLM gateway/router → Inference cluster
**Side channels off the LLM gateway:** Observability, Governance

![Internal LLM exposure architecture diagram](architecture-diagram.png)

---

## Layer 1 — API gateway (edge)
Generic edge concerns only: authN/Z (OIDC/OAuth2, mTLS), per-team rate limiting, request size limits, WAF filtering. Routes `/llm/*` to the LLM gateway as an upstream — it does not know about models.

| Tool | Notes |
|---|---|
| **Kong Gateway (OSS)** | Largest plugin ecosystem, Kong Ingress Controller for k8s/k3s |
| **APISIX** | Apache project, etcd-backed, dynamic routing + hot-reload plugins |
| **Envoy Gateway** | Fits naturally if standardizing on Envoy / considering Istio later |
| **Traefik** | Simplest to operate on k3s specifically; lowest ops overhead |

## Layer 2 — LLM gateway / router
Unified OpenAI-compatible schema across backend models. Model routing by alias/team/task, fallback chains, per-team token budgets, usage metering for chargeback, prompt/response caching.

| Tool | Notes |
|---|---|
| **LiteLLM Proxy** | Most mature option; budgets, virtual keys, fallback routing, built-in Prometheus metrics |
| **Portkey Gateway (OSS core)** | Similar scope, built-in guardrail hooks + caching |
| **Helicone** | Logging/cost-tracking proxy — observability-first; pair with LiteLLM rather than replace it |
| **BricksLLM** | Go-based, lighter-weight alternative to reduce Python in the request path |

## Layer 3 — Inference serving
Self-hosted model serving on the GPU cluster (k3s / KAI Scheduler / three-tier GPU partitioning).

| Tool | Notes |
|---|---|
| **vLLM** | PagedAttention, continuous batching, broadest model support |
| **SGLang** | RadixAttention caching, faster for structured/JSON-heavy or agentic workloads |
| **TGI (Hugging Face)** | Rust-based serving, lower Python overhead |
| **Ray Serve** | Single control plane across heterogeneous serving backends |

## Layer 4 — Guardrails / governance
Prompt-injection detection, output PII redaction, policy enforcement, audit trail — treated as first-class given regulated-decisioning context (ECOA/FCRA/UDAAP/GLBA).

| Tool | Notes |
|---|---|
| **NeMo Guardrails** (NVIDIA) | Programmable rails for topic/jailbreak/PII policy |
| **Guardrails AI** | Schema validation, structured output enforcement |
| **Presidio** (Microsoft) | PII detection/redaction, pre- and post-inference |
| **Llama Guard / Prompt Guard** (Meta) | Small classifier model for prompt-injection / unsafe-content screening |

## Layer 5 — Observability
| Tool | Notes |
|---|---|
| **Prometheus + Grafana** | GPU util, queue depth, tokens/sec — vLLM and SGLang expose Prometheus endpoints natively |
| **OpenTelemetry** | Tracing across gateway → router → inference hops |
| **Langfuse** | LLM-specific tracing: prompt/response logging, token cost, eval scoring, self-hostable |
| **Loki** | Log aggregation if already on the Grafana stack |

## Model / artifact management
| Tool | Notes |
|---|---|
| **MLflow** | Model registry/versioning — supports "which model version served which decision" audit trail |
| **Ray + KubeRay** | Orchestration for fine-tuning or batch eval alongside serving |

---

### Recommended minimal stack
**Traefik or Kong → LiteLLM Proxy → vLLM/SGLang on k3s**, with **Presidio + NeMo Guardrails** on the LiteLLM layer and **Prometheus/Grafana + Langfuse** for observability. Five OSS projects total, fully self-hostable, no external API calls in the request path.
